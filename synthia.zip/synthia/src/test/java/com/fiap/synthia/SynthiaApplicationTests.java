package com.fiap.synthia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SynthiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
