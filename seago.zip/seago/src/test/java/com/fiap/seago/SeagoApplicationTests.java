package com.fiap.seago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
